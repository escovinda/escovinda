# PIXEL HORROR CREEPYPASTA THEME

A Pen created on CodePen.io. Original URL: [https://codepen.io/aeon-flexx-dead-girl/pen/MWMZeZm](https://codepen.io/aeon-flexx-dead-girl/pen/MWMZeZm).

a theme for neocities or any other html based static site situation, feel free to use it, credit me or not i dont mind, but perhaps consider donating to me here-

coindrop.to/numbpilled